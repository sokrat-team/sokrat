package sokrat.main;

public interface AffectationStrategy {

    public void giveRideTo(Vehicle vehicle, int step);
}
