package sokrat.main;

public class ParserExcception extends Exception{
    public ParserExcception(String s) {
        super(s);
    }
}
